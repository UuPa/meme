﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Chloe.Admin.Areas
{
    public static class AreaNames
    {
        public const string System = "System";
        public const string Wiki = "Wiki";
    }
}
