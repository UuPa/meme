﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ace
{
    public static class Globals
    {
        public static IServiceProvider Services { get; set; }
        public static IConfigurationRoot Configuration { get; set; }
    }
}
